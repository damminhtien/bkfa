<?php $__env->startSection('content'); ?>
<div id="root">
	<?php if(count($errors) > 0): ?>
	<br><br>
	<div class="alert alert-danger">
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($err); ?><br>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	<?php endif; ?>
	<?php if(session('thongbao')): ?>
	<br><br>
	<div class="alert alert-danger"> 
		<?php echo e(session('thongbao')); ?>

	</div>
	<?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/marked/0.3.6/marked.js" type="text/javascript" charset="utf-8"></script>
<script>
$('document').ready(()=>{
	$.get('https://raw.githubusercontent.com/damminhtien/bkfa/master/readme.md', function(data) {
			chuoi = marked(data);
		console.log(chuoi);
		$('#root').html(chuoi);
	}, 'text');
})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>