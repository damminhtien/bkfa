 
<?php $__env->startSection('style'); ?>
  <link href="css/admin_thumbnail.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="page-title">
        <h4><?php echo e(Lang::get('sub.datasheet')); ?><strong><?php echo e(Lang::get('sub.news')); ?> <?php echo "- " .count($tintuc). ""; ?> <?php echo e(Lang::get('sub.record')); ?></strong>
        <a href="admin/tintuc/them" title="<?php echo e(Lang::get('sub.add_news')); ?>"><button type="button" class="btn-success btn" style="float: right;" ><i class="ti-plus" ></i></button></a>
     <?php if(count($errors) > 0): ?>
      <br><br>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($err); ?><br>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        <?php endif; ?>
        <?php if(session('thongbao')): ?>
            <br><br>
            <div class="alert alert-success"> 
                <?php echo e(session('thongbao')); ?>

            </div>
        <?php endif; ?>
        </h4>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-block">
                    <div class="table-striped">
                        <table id="dt-opt" class="table table-lg table-hover">
                            <thead>
                                <tr>
                                    <th>STT</th>
                                    <th><?php echo e(Lang::get('sub.title')); ?></th>
                                    <th><?php echo e(Lang::get('sub.about')); ?></th>
                                    <th><?php echo e(Lang::get('sub.content')); ?></th>
                                    <th><?php echo e(Lang::get('sub.image')); ?></th>
                                    <th><?php echo e(Lang::get('sub.date')); ?></th>
                                    <th><?php echo e(Lang::get('sub.view')); ?></th>
                                    <th><?php echo e(Lang::get('sub.edit')); ?></th>
                                    <th><?php echo e(Lang::get('sub.delete')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                              <?php $i=0 ?>
                              <?php $__currentLoopData = $tintuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                      <td>
                                          <div class="mrg-top-15">
                                              <span class="text-info"><i><?php echo ++$i ?></i></span>
                                          </div>
                                      </td>
                                      <td>
                                          <div class="mrg-top-15">
                                              <div class="thumbnail">
                                                <h5><?php echo e(cutString($s->tieude, 20)); ?></h5>
                                                <p><?php echo e($s->tieude); ?></p>
                                              </div>
                                          </div>
                                      </td>
                                      <td>
                                          <div class="mrg-top-15">
                                              <div class="thumbnail">
                                                <h5><?php echo e(cutString($s->gioithieu, 20)); ?>

                                                </h5>
                                                <p>
                                                    <?php  
                                                      echo $s->gioithieu
                                                    ?>
                                                </p>
                                              </div>
                                          </div>
                                      </td>
                                      <td>
                                          <div class="mrg-top-15">
                                              <a class="btn btn-icon btn-flat btn-rounded dropdown-toggle" data-toggle="modal" data-target="#myModal<?php echo e($s->idtintuc); ?>"> 
                                              <h3 class="ti-eye text-info"></h3>
                                            </a>
                                            <!-- Modal -->
                                            <div class="modal fade" id="myModal<?php echo e($s->idtintuc); ?>" tabindex="-1" role="text" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-lg" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Chi tiết ghi chú</h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="container">
                                                              <?php  
                                                              echo $s->noidung
                                                              ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                          </div>
                                      </td>
                                      <td>
                                          <div>
                                              <div class="thumbnail" href="#"><img src="upload/images/tintuc/<?php echo e($s->urlanh); ?>" width="60" height="40" >
                                              <span><img src="upload/images/tintuc/<?php echo e($s->urlanh); ?>" with="300" height="250" title="Ảnh <?php echo e($s->urlanh); ?>"></span></div>
                                          </div>
                                      </td>
                                      <td>
                                          <div class="mrg-top-15">
                                              <h5><?php echo e($s->created_at); ?></h5>
                                          </div>
                                      </td>
                                      <td>
                                          <div class="mrg-top-15">
                                              <h5><?php echo e($s->luotxem); ?></h5>
                                          </div>
                                      </td>
                                      <td>
                                          <div class="mrg-top-15">
                                            <a href="admin/tintuc/sua/<?php echo e($s->idtintuc); ?>" title="Sửa <?php echo e(cutString($s->tieude, 60)); ?>"><button class="btn btn-icon btn-flat btn-rounded dropdown-toggle"> 
                                              <h3 class="ti-pencil-alt"></h3>
                                            </button></a>
                                          </div>
                                      </td>            
                                      <td>
                                          <div class="mrg-top-15">
                                            <button class="btn btn-icon btn-flat btn-rounded dropdown-toggle" data-toggle="modal" data-target="#xoaModal<?php echo e($s->idtintuc); ?>" title="Xoá <?php echo e(cutString($s->tieude, 40)); ?>">  
                                              <h3 class="ti-trash text-danger"></h3>
                                            </button></a>
                                            <?php echo $__env->make('admin.tintuc.xoa', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                          </div>
                                      </td>
                                  </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
  <script type="text/javascript">
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>