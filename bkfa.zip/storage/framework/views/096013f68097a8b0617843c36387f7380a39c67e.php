<!-- Modal -->
<div class="modal fade" id="xoaModal<?php echo e($dt->iddethi); ?>" tabindex="5" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo e(Lang::get('sub.delete')); ?> slide<strong><?php echo e(cutString($dt->gioithieu, 40)); ?></strong></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container" align="right">
                    <button class="btn btn-default" data-dismiss="modal"><?php echo e(Lang::get('sub.cancel')); ?></button>
                    <a href="admin/dethi/xoa/<?php echo e($dt->iddethi); ?>" title="<?php echo e(Lang::get('sub.delete')); ?>">
                        <button class="btn btn-danger"><?php echo e(Lang::get('sub.submit')); ?></button>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>