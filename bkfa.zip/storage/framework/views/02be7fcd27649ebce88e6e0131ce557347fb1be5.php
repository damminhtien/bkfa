 
<?php $__env->startSection('title', 'Kết quả tìm kiếm'); ?> 
<?php $__env->startSection('content'); ?>
<!-- home -->
<div id="home-p" class="home-p pages-head1 text-center">
    <div class="container">
        <form action="tim-kiem" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="input-group ">
                <input type="text" class="form-control" id="inlineFormInputGroup" placeholder="Tìm kiếm" name="search">
                <button type="submit" class="input-group-addon"><i class="fa fa-search"></i></button>
            </div>
        </form>
    </div>
    <!--/end container-->
</div>
<!-- kết quả search -->
<section>
    <div class="row">
        <div class="col-xs-11 col-sm-11 col-md-11 wow fadeInUp" data-wow-delay="0.3s">
            <div class="service-h-desc">
                <h3><?php echo e(Lang::get('sub.resultsearch')); ?></h3>
                <div class="heading-border-light"></div>
                <hgroup>
                    <h2 class="lead"><strong class="cl-blue"><?php echo e($sokq); ?></strong> <?php echo e(Lang::get('sub.resultsearch')); ?>: <?php echo e($req); ?> <strong class="cl-blue"></strong></h2>
                </hgroup>
                <div class="service-h-tab">
                    <nav class="nav nav-tabs" id="myTab" role="tablist">
                        <a class="nav-item nav-link active" id="test-profile-tab" data-toggle="tab" href="#test-profile" role="tab" aria-controls="test-profile"><?php echo e(Lang::get('sub.subject')); ?></a>
                        <a class="nav-item nav-link" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-expanded="true"><?php echo e(Lang::get('sub.exam')); ?></a>
                        <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile">Slide</a>
                        <a class="nav-item nav-link" id="my-profile-tab" data-toggle="tab" href="#my-profile" role="tab" aria-controls="my-profile"><?php echo e(Lang::get('sub.news')); ?></a>
                    </nav>
                    <div class="tab-content" id="nav-tabContent">
                        <div class="tab-pane fade show active" id="test-profile" role="tabpanel" aria-labelledby="test-profile-tab">
                         <div id="document-1" class="row">
                            <?php $__currentLoopData = $mon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-6 mb-4">
                                <div class="card ">
                                 
                                 <div class="card-body text-center">
                                    <div class="card-title">
                                        <a href="#"><strong style="color: #000"><?php echo e($ds->ten); ?></strong></a>
                                    </div>
                                    <p style="color: #0C48BA"><?php echo e($ds->gioithieu); ?></p>
                                    <div class="cart-icon text-center" style="position:absolute; bottom:20px; margin-left: 22px;">
                                        <a href="danh-sach-slide/<?php echo e($ds->idmon); ?>/<?php echo e($ds->tenkhongdau); ?>.html"><i class="fa fa-book" aria-hidden="true"></i> Slide</a>
                                        <a href="danh-sach-de-thi/<?php echo e($ds->idmon); ?>/<?php echo e($ds->tenkhongdau); ?>.html"><i class="fa fa-sticky-note-o" aria-hidden="true"></i> Đề thi</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>    
                </div>
                        <div class="tab-pane fade" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                            <div class="row ">
                                <?php $__currentLoopData = $dethi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-3 col-sm-6 desc-document wow fadeInUp" data-wow-delay="0.4s">
                                    <div class="desc-document-cont">
                                        <div class="thumbnail-blogs ">
                                            <img src="upload/images/<?php echo e($dt->urlanh); ?> " class="img-fluid " alt="<?php echo e($dt->gioithieu); ?> ">
                                        </div>
                                        <div>
                                            <h3><?php echo e(cutString($dt->gioithieu, 33)." ..."); ?></h3>
                                            <p class="desc"><?php echo e($dt->nam); ?></p>
                                        </div>
                                        <div>
                                            <a href="#"><i class="fa fa-heart-o"> 1</i></a>
                                            <a href="#"><i class="fa fa-eye"></i> 2</a>
                                            <a href="#"><i class="fa fa-arrow-circle-o-down"></i> 3</a>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            
                        </div>
                        
                <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                    <div class="row">
                     <?php $__currentLoopData = $slide; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                     <div class="col-md-3 col-sm-6 desc-document wow fadeInUp" >
                        <div class="desc-document-cont">
                            <div class="thumbnail-blogs ">

                            </div>
                            
                                <div>
                                    <h3><?php echo e(cutString($sl->gioithieu, 33)." ..."); ?></h3>
                                    <p class="desc"><?php echo e($sl->nam); ?></p>
                                </div>
                                <div>
                                    <a href="#"><i class="fa fa-heart-o"> 1</i></a>
                                    <a href="#"><i class="fa fa-eye"></i> 2</a>
                                    <a href="#"><i class="fa fa-arrow-circle-o-down"></i> 3</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="tab-pane fade" id="my-profile" role="tabpanel" aria-labelledby="my-profile-tab">
                    <div class="row">  
                        <section class="col-xs-12 col-sm-6 col-md-12">
                            <?php $__currentLoopData = $tintuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="search-result row">
                                <div class="col-xs-12 col-sm-12 col-md-3">
                                    <a href="#" title="<?php echo e($tt->tieude); ?>" class="thumbnail"><img src="upload/tintuc/<?php echo e($tt->tieudeurlanh); ?>" class="img-fluid" alt="<?php echo e($tt->tieude); ?>" /></a>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-2">
                                    <ul class="meta-search">
                                        <li><i class="fa fa-calendar"></i> <span>
                                            <?php echo e($tt->updated_at->format('m/d/Y')); ?>

                                        </span></li>
                                        <li><i class="fa fa-clock-o"></i> <span><?php echo e($tt->updated_at->format('H:i:s')); ?></span></li>
                                        <li><i class="fa fa-tags"></i> <span>People</span></li>
                                    </ul>
                                </div>
                                <div class="col-xs-12 col-sm-12 col-md-7 excerpet">
                                    <h3><a href="#" title=""><?php echo e(cutString($tt->gioithieu, 10)." ..."); ?></a></h3>
                                    <p><?php echo cutString($tt->noidung, 50) ."..."; ?></p>
                                </div>
                                <span class="clearfix borda"></span>
                            </article>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </section>
                    </div>
                </div>
                <div class="result-view" align="left">
                    <a href="#" class="btn btn-general btn-green" role="button">Xem thêm</a>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>
</section>
<!-- end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>