 
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="page-title">
	    <div class="page-header">
	        <h4><small><?php echo e(Lang::get('sub.edit')); ?></small><?php echo e(Lang::get('sub.news')); ?></h4>
	    </div>
    </div>
	<div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-block">
		            <?php if(count($errors) > 0): ?>
		                <div class="alert alert-danger">
		                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                        <?php echo e($err); ?><br>
		                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                </div>
		            <?php endif; ?>
		            <?php if(session('thongbao')): ?>
		                <div class="alert alert-success"> 
		                    <?php echo e(session('thongbao')); ?>

		                </div>
		            <?php endif; ?>
		            <form action="admin/tintuc/sua/<?php echo e($tintuc->idtintuc); ?>" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    
                    <div class="form-group">
                        <label><?php echo e(Lang::get('sub.title')); ?></label>
                        <input class="form-control" name="tieude" value="<?php echo e($tintuc->tieude); ?>"></input>
                    </div>
                    <div class="form-group">
                        <label><?php echo e(Lang::get('sub.about')); ?></label>
                        <textarea name="gioithieu" class="form-control" rows="3"><?php echo e($tintuc->gioithieu); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label><?php echo e(Lang::get('sub.content')); ?></label>
                        <textarea name="noidung" class="form-control ckeditor" rows="10"><?php echo e($tintuc->noidung); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label><?php echo e(Lang::get('sub.image')); ?></label><br>
                        <p><img with="300" height="300" src="upload/images/tintuc/<?php echo e($tintuc->urlanh); ?>"></p>
						<label>
                    		<span class="text-primary btn btn-lg btn-outline-primary"><i class="fa fa-camera"></i><?php echo e(Lang::get('sub.select_image')); ?></span>
                    		<p id="filename" class="d-inline"></p>
                    		<input type="file" name="anh" style="display: none;">
                    	</label>
                    	<div style="width: 50vw;" id="imgupload">	
                    	</div>
                    </div>
                    <button type="submit" class="btn btn-success btn-lg float-right" id="btnSubmit"><?php echo e(Lang::get('sub.edit')); ?><i class="fa fa-paper-plane"></i></button>
                    <button type="reset" class="btn btn-lg float-right btn-secondary"><?php echo e(Lang::get('sub.refresh')); ?><i class="fa fa-undo"></i></button>
                </form>
		        </div>
    		</div>
		</div>	
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function(){
            $("input[name=file]").change(function(){
            	$("#filename").html($("input[name=file]").val());
            });
            $("input[name=anh]").change(function(e) {
		    	var file = e.originalEvent.srcElement.files[e.originalEvent.srcElement.files.length-1];
    			var img = document.createElement("img");
    			var reader = new FileReader();
    			reader.onloadend = function() {
         			img.src = reader.result;
    			}
    			reader.readAsDataURL(file);
    			$("#imgupload").html(img);
    			img.width = "200";
			});
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>