 <?php $__env->startSection('title', 'Danh sách đề thi'); ?> <?php $__env->startSection('content'); ?>

<div id="home-p" class="home-p pages-head4 text-center">
    <div class="container">
        <form action="tim-kiem" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="input-group ">
                <input type="text" class="form-control" id="inlineFormInputGroup" placeholder="Tìm kiếm" name="search">
                <button type="submit" class="input-group-addon"><i class="fa fa-search"></i></button>
            </div>
        </form>
    </div>
    <!--/end container-->
</div>

<section>
    <div class="container">
        <div  id="document" class="container-fluid ">
            <div class="wrapper row">
                <?php $__currentLoopData = $dethi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 col-sm-6 desc-document wow fadeInUp" data-wow-delay="0.4s">
                    <a href="chi-tiet-de-thi/<?php echo e($ds->idmon); ?>/de<?php echo e($ds->iddethi); ?>.html" style="text-decoration: none;">
                        <div class="desc-document-cont">
                            <div class="thumbnail-blogs ">
                                <img src="upload/images/dethi/anh/<?php echo e($ds->urlanh); ?> " class="img-fluid " alt="<?php echo e($ds->gioithieu); ?> ">
                            </div>
                            <div>
                                <h3><?php echo e(cutString($ds->gioithieu, 33)." ..."); ?></h3>
                                <p class="desc"><span class="fa fa-user" style="color: #1520F5"></span><b style="color: #731717"> BKFA</b></p>
                            </div>
                            <div class="document-footer">
                                <i class="fa fa-calendar"> <?php echo e($ds->nam); ?></i>
                                <i class="fa fa-eye"> <?php echo e($ds->luotxem); ?></i>
                                <i class="fa fa-arrow-circle-o-down"> 3</i>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <nav aria-label="Page navigation" style="margin-top: 50px;">
                <ul class="pagination justify-content-center">
                    <?php echo e($dethi->links()); ?>

                </ul>
            </nav>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>