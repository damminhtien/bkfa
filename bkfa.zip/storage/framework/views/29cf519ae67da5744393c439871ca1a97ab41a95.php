<!-- Modal -->
<div class="modal fade" id="xoaModal<?php echo e($s->idtintuc); ?>" tabindex="5" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo e(Lang::get('sub.delete')); ?> <?php echo e(Lang::get('sub.news')); ?><strong><?php echo e(cutString($s->tieude, 40)); ?></strong></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="container" align="right">
                    <button class="btn btn-default" data-dismiss="modal"><?php echo e(Lang::get('sub.cancel')); ?></button>
                    <a href="admin/tintuc/xoa/<?php echo e($s->idtintuc); ?>" title="<?php echo e(Lang::get('sub.delete')); ?>">
                        <button class="btn btn-danger"><?php echo e(Lang::get('sub.submit')); ?></button>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>