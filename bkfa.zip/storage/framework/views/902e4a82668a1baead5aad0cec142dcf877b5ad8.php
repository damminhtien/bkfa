<?php $__env->startSection('title', 'Danh sách tài liệu'); ?>

<?php $__env->startSection('content'); ?>

<div id="home-p" class="home-p pages-head2 text-center">
    <div class="container">
        <form action="tim-kiem" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
            <div class="input-group ">
                <input type="text" class="form-control" id="inlineFormInputGroup" placeholder="Tìm kiếm" name="search">
                <button type="submit" class="input-group-addon"><i class="fa fa-search"></i></button>
            </div>
        </form>
    </div>
    <!--/end container-->
</div>
<!-- Danh sách tài liệu -->
<section id="document-1" class="document-1">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $dsmon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ds): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card ">
                 
                    <div class="card-body text-center">
                        <div class="card-title">
                            <a href="#"><strong style="color: #000"><?php echo e($ds->ten); ?></strong></a>
                        </div>
                        <p style="color: #0C48BA"><?php echo e($ds->gioithieu); ?></p>
                        <div class="cart-icon text-center" style="position:absolute; bottom:20px; margin-left: 22px;">
                            <a href="danh-sach-slide/<?php echo e($ds->idmon); ?>/<?php echo e($ds->tenkhongdau); ?>.html"><i class="fa fa-book" aria-hidden="true"></i> Slide</a>
                            <a href="danh-sach-de-thi/<?php echo e($ds->idmon); ?>/<?php echo e($ds->tenkhongdau); ?>.html"><i class="fa fa-sticky-note-o" aria-hidden="true"></i> Đề thi</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <nav aria-label="Page navigation" style="margin-top: 50px;">
            <ul class="pagination justify-content-center">
                <?php echo e($dsmon->links()); ?>

            </ul>
        </nav>
    </div>
</section>
<!-- end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('pages.layouts.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>