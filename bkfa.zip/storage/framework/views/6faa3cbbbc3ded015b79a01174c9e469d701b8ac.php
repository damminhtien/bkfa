<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'BKFA')); ?></title>
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>

<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e(config('app.name', 'BKFA')); ?>

                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <style>
                body {
                    background: #f39c12;
                }

                select {
                    -webkit-appearance: none;
                    -moz-appearance: none;
                    -ms-appearance: none;
                    appearance: none;
                    outline: 0;
                    box-shadow: none;
                    border: 0 !important;
                    background: #3e7cb4;
                    color: #FFF;
                    background-image: none;
                }

                select option{
                    background: #fff;
                    color: #000;
                }
                /* Custom Select */

                .select {
                    position: relative;
                    display: block;
                    width: 10em;
                    height: 3em;
                    line-height: 3;
                    background: #2c3e50;
                    overflow: hidden;
                    border-radius: .25em;
                }

                select {
                    width: 100%;
                    height: 100%;
                    margin: 0;
                    padding: 0 0 0 .5em;
                    color: #fff;
                    cursor: pointer;
                }

                select::-ms-expand {
                    display: none;
                }
                /* Arrow */

                .select::after {
                    content: '\25BC';
                    position: absolute;
                    top: 0;
                    right: 0;
                    bottom: 0;
                    padding: 0 1em;
                    background: #B70D05;
                    pointer-events: none;
                }
                /* Transition */

                .select:hover::after {
                    color: #f39c12;
                }

                .select::after {
                    -webkit-transition: .25s all ease;
                    -o-transition: .25s all ease;
                    transition: .25s all ease;
                }
                </style>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                        <form action="<?php echo e(route('switchLang')); ?>" class="form-lang" method="post">
                            <div class="select">
                                <select name="locale" onchange='this.form.submit();'>
                                    <option value="en"><?php echo e(trans('sub.lang.en')); ?></option>
                                    <option value="vi" <?php echo e(Lang::locale()==='vi' ? 'selected' : ''); ?>><?php echo e(trans('sub.lang.vi')); ?></option>
                                </select>
                            </div>
                            <?php echo e(csrf_field()); ?>

                        </form>
                    </ul>
                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                        <li><a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(Lang::get('sub.login')); ?></a></li>
                        <li><a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(Lang::get('sub.register')); ?></a></li>
                        <?php else: ?>
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->ten); ?> <span class="caret"></span>
                                </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(Lang::get('sub.logout')); ?>

                                    </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>

</html>