<link rel="stylesheet" href="css/box.css">

<div id="facebook" class="fb-left sort-order-1">
    <div class="facebook_icon"><i class="fa fa-facebook"></i></div>
    <div class="fb-page" data-href="https://www.facebook.com/bkfateam/" data-small-header="true" data-adapt-container-width="true" data-hide-cover="true" data-show-facepile="true" data-show-posts="false">
        <div class="fb-xfbml-parse-ignore">
            <blockquote cite="https://www.facebook.com/bkfateam/"><a href="https://www.facebook.com/bkfateam/">BKFA</a></blockquote>
        </div>
    </div>
    <div id="fb-root"></div>
    <script>
    (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s);
        js.id = id;
        js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.5&appId={https://www.facebook.com/bkfateam/}";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));
    </script>
</div>

<div id="twitter_footer" class="twit-left sort-order-2">
    <div class="twitter_icon"><i class="fa fa-twitter"></i></div>
    <a class="twitter-timeline" href="https://twitter.com/BKFA_Team?ref_src=twsrc%5Etfw">Tweets by BKFA_Team</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
    <a href="https://twitter.com/BKFA_Team?ref_src=twsrc%5Etfw" class="twitter-follow-button" data-show-count="false">Follow @BKFA_Team</a><script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
    <a href="https://twitter.com/intent/tweet?screen_name=BKFA_Team&ref_src=twsrc%5Etfw" class="twitter-mention-button" data-show-count="false">Tweet to @BKFA_Team</a><script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
</div>

<div id="video_box" class="vb-left sort-order-3">
    <div id="video_box_icon"><i class="fa fa-play"></i></div>
    <p>
        <iframe id="youtube" width="560" height="315" src="https://www.youtube.com/embed/etq4Iqx3hnk" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
    </p>
</div>

<div id="fb-root"></div>
<script>
(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = 'https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v3.0&appId=204934146962428&autoLogAppEvents=1';
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
</script>

<script src="library/js/jquery/jquery.min.js"></script>
<script src="js/box.js"></script>


