<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v2.12&appId=565933070461786&autoLogAppEvents=1';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

# BKFA

## Welcome to BKFA.com GitHub pages :sparkles: :sparkles: :sparkles:

### We are BKFA from HUST 

<b>Party with us</b>

<img src="https://octodex.github.com/images/yaktocat.png" class="page-body">

<img src="https://i.ytimg.com/vi/NLSue7sTDMo/maxresdefault.jpg" class="page-body">

### Our team 

<img src="https://media.giphy.com/media/1ZtmZoLRtnfjBW1giN/giphy.gif" class="page-body">

<img src="https://media.giphy.com/media/5wFUxatvUMXJ9JhpVp/giphy.gif" class="page-body">

<img src="https://media.giphy.com/media/1lwtswtRpqDBcn9UVI/giphy.gif" class="page-body">

<img src="https://media.giphy.com/media/d5qqj1zFg3Z3uLS2xS/giphy.gif" class="page-body">

<img src="https://media.giphy.com/media/3XA0mnQR0zhD7OZAbG/giphy.gif" class="page-body">

### Want music ? :bouquet:
<div class="page-body">
<iframe width="560" height="315" src="https://www.youtube.com/embed/dvntgt7IsOg" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen class="page-body"></iframe>

<div class="fb-video page-body" data-href="https://www.facebook.com/DamMinhTienn/videos/573056529746855/" data-width="500" data-show-text="true"><blockquote cite="https://www.facebook.com/DamMinhTienn/videos/573056529746855/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/DamMinhTienn/videos/573056529746855/">Vui nhộn</a><p>:)
.
.
.
.
.
.
.
See it on github: https://github.com/damminhtien/HappyWomanDay2018</p>Người đăng: <a href="https://www.facebook.com/DamMinhTienn/">Đàm Minh Tiến</a> vào 9 Tháng 3 2018</blockquote></div>

</div>

# About BKFA.com
### Purpose

<p align="justify" >BKFA.com is a project of the BKFA team from HUST for the purpose of bringing the academic materials of the subjects / institutes to a storage facility. From there, students at the school and abroad can easily search and review the subjects within the framework of Hanoi University of Technology. In addition, people can update the study news, confession, tips from us. The project has been developed since February 2018.
</p>

<p align="center" class="page-body"><img src="https://media.licdn.com/mpr/mpr/AAEAAQAAAAAAAAUmAAAAJDU0OTRjMjQ0LTU3MWMtNDJmOS05NzllLTU2Y2M2ZGFlOTZhYQ.jpg"></p>

### Technology

- Laravel framework (LAMP stack)
- Bootstrap 4.0 + Jquery
- Social plugin
- Another stylesheet css sources

### About BKFA

We are students of HUST   
- damminhtien
- trantrongbinh
- assassin881997
- 0henri0

with love <3

<div class="fb-share-button" data-href="https://damminhtien.github.io/bkfa/" data-layout="button_count" data-size="large" data-mobile-iframe="true"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fdamminhtien.github.io%2Fbkfa%2F&amp;src=sdkpreparse" class="fb-xfbml-parse-ignore">Chia sẻ</a></div>
<div class="fb-like" data-href="https://damminhtien.github.io/bkfa/" data-layout="box_count" data-action="like" data-size="large" data-show-faces="true" data-share="true"></div>
<div class="fb-comments" data-href="https://damminhtien.github.io/bkfa/" data-numposts="5"></div>
<script type="text/javascript" src="https://platform.twitter.com/widgets.js"></script>
<script src="https://lab.hakim.se/zoom-js/js/zoom.js"></script>
<script>
document.querySelector( '.page-body' ).addEventListener( 'click', function( event ) {
	event.preventDefault();
	zoom.to({ element: event.target });
} );
</script>
